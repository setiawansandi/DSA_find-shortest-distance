#include <iostream>
#include <stdlib.h>             // abs (absolute value)
#include <vector>
#include <algorithm>            // std::next_permutation
#include <string>
#include <fstream>

using namespace std;

class coordinate {
public:
    int x;
    int y;
    int location;

    coordinate() {  //origin
        x = 0;
        y = 0;
        location = 0;
    }

    coordinate(int, int, int);
};

coordinate::coordinate(int a, int b, int c) { //constructor
    x = a;
    y = b;
    location = c;
}

// Permutation condition
struct compareNodes {
    bool operator()(const coordinate& a, const coordinate& b) const {
        return a.location < b.location;
    }
};


int calculate_distance(coordinate a, coordinate b) {
    return (abs(a.x - b.x) + abs(a.y - b.y));
}

void print_coord(string** output_table, int racksize[], vector <coordinate> graph, int j) {
    for (int i = racksize[1]; i >= 0; i--) {
        for (int j = 0; j <= racksize[0]; j++) {
            cout << " " << output_table[i][j];              // print out the content stored in the 2d array
        }
        cout << endl;
    }
    if (j != 0)cout << "(" << graph[j].x << "," << graph[j].y << ") " << "retrieved" << endl;      // display which coordinate has been retrieved
    else cout << "H - Home (" << graph[j].x << "," << graph[j].y << ") " << endl;
    cout << endl;
}

void display_coordinates(vector <coordinate> graph, int racksize[]) {
    // create a 2d matrix to store the coordinates that need to be printed out
    string** output_table = new string * [racksize[1] + 1];      // row

    for (int y = racksize[1]; y >= 0; y--) {
        output_table[y] = new string[racksize[0] + 1];           // col

        for (int x = 0; x <= racksize[0]; ++x) {

            for (int k = 1; k < static_cast<int>(graph.size()); k++) {        // variable "k" to navigate the vector
                if (y == graph[0].y && x == graph[0].x) {   // origin
                    output_table[y][x] = "H";
                    break;
                }
                else {
                    if (y == graph[k].y && x == graph[k].x) { // if x and y match the coordinates stored in vector, store 'X'
                        output_table[y][x] = "X";
                        break;
                    }
                    else output_table[y][x] = "O";
                    // else (k == graph.size() - 1)
                }
            }
        }
    }

    for (int i = 0; i < static_cast<int>(graph.size()); i++) {
        if(i != 0) output_table[graph[i].y][graph[i].x] = to_string(graph[i].location); // use to_string to convert int to string (otherwise it will be converted to char symbol)
        print_coord(output_table, racksize, graph, i);
    }

    //delete matrix
    for (int y = racksize[1]; y >= 0; y--) {
        delete[] output_table[y];               // delete rows
    }
    delete[] output_table;                      // delete pointers that point to rows
    output_table = NULL;                        // remove pointer (that point to pointers) from stack
}


void findDistance() {
    // ======== File Reader ========
    vector <coordinate> position;
    string dataX, dataY, ignore, file_name;
    int racksize[2];
    int numOfpoint = 0, x, y, location;

    coordinate origin;
    position.push_back(origin);

    cout << "Enter the filename: ";
    cin >> file_name;

    ifstream myfile(file_name);
    if (myfile.is_open())
    {
        getline(myfile, ignore);                  // ignore "size: "
        // get rack size
        getline(myfile, dataX, ',');
        racksize[0] = stoi(dataX);                // stoi = string to integer
        getline(myfile, dataY, '\n');
        racksize[1] = stoi(dataY);

        getline(myfile, ignore);                  // ignore "x, y"

        while (!myfile.eof())                     // while not the end of file
        {
            ++numOfpoint;                         // count number of coodinates

            getline(myfile, dataX, ',');
            x = stoi(dataX);
            getline(myfile, dataY, '\n');
            y = stoi(dataY);
            location = numOfpoint;

            position.push_back(coordinate(x, y, location));
        }
        myfile.close();
    }
    else {
        cout << "Unable to open file" << endl;
        return;
    }
    // ======== //file reader =========


    // make a 2d matrix that store distance between two point for all the points
    int** matrix = new int* [numOfpoint + 1];   // row,     (numOfpoint+1) because + origin(0, 0)

    // loop to compute all the distance between every pair of points in the 'position' vector
    for (int i = 0; i < numOfpoint + 1; i++) {
        matrix[i] = new int[numOfpoint + 1];    // col

        for (int j = 0; j < numOfpoint + 1; j++) {
            matrix[i][j] = calculate_distance(position[i], position[j]);
        }

    }


    // ============= compare all distance =================
    int min_distance = INT_MAX; // initialize min_distance with maximum value
    vector <coordinate> graph;  // to store the sequence that has minimum distance

    // Loop to compute the distance for every possible permutation
    do {
        int distance = 0;
        int prev = 0; // start from 0 (origin)

        //cout << "Sequence: "; //5

        // compute total distance covered for every co-ordinate points
        for (int i = 1; i <= numOfpoint; i++) {
            distance = distance + matrix[prev][position[i].location];
            prev = position[i].location;
            //cout << position[i].location << " ";
            //cout << "(" << position[i].x << "," << position[i].y << ")  ";   // display x and y coordinates linked to the respective node
        }
        //cout << "\tdistance: " << distance;

        // if distance is less than minimum value then update it
        if (distance < min_distance) {
            min_distance = distance;
            graph.assign(position.begin(), position.end());
        }

        //cout << endl;

    } while (next_permutation(position.begin() + 1, position.end(), compareNodes())); 
    // (position.begin + 1) as we don't want to include origin(0, 0) in the permutation

    cout << "\nMinimum distance: " << min_distance << endl << endl;

    // ============= //compare all distance =================

    display_coordinates(graph, racksize);

    // delete matrix
    for (int i = 0; i < numOfpoint + 1; i++) {
        delete[] matrix[i];               // delete rows
    }
    delete[] matrix;                      // delete pointers that point to rows
    matrix = NULL;                        // remove pointer (that point to pointers) from stack
}


int main() {
    findDistance();
    return 0;
}